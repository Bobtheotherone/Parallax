# Adaptive Representation Lab

**Task-adaptive languages over stable, checkable meanings.**

A Markdown-only, GitHub-ready research starter for an LLM that selects and
constructs small task-specific programming interfaces. The working name of the
method is **adaptive representation synthesis**. This is a proposal and a small
reference implementation, not a claim of a new field's priority or proven gains.

## Start

An agent should read [START.md](START.md), not recursively load this repository.
A human should read [the thesis](research/THESIS.md) and
[the experimental design](research/EVALUATION.md).

Paste this instruction into a repository-enabled coding agent:

> Read START.md and follow the route for my task. First freeze the task contract
> and report available execution capabilities. Prefer an existing representation.
> Create a new capsule only when its expected benefit justifies its full cost.
> Do not invent tool results, primitives, guarantees, or native backends.

Every tracked deliverable is `.md`. Structured artifacts live in JSON fences;
the optional executable reference lives in a Python fence. An agent needs actual
file access; a GitHub URL, file name, or AGENTS.md does not itself install a tool
or guarantee that any particular agent will load these instructions.

## What works in v0.1

The [intseq pack](packs/intseq/PACK.md) selects from seven fixed typed primitives
and permits checked, nonrecursive, compositional macros. The reference validates
capsules, checks program types and capsule hashes, expands macros, and interprets
bounded integer-sequence programs. An [end-to-end example](examples/intseq/TASK.md)
includes a frozen task, capsule, program, and actual [test evidence](examples/intseq/EVIDENCE.md).

A [compact programmer packet](examples/intseq/PACKET.md) combines the task, selected
semantics, capsule, and output contract for a single generation call. Its source
identities are recorded so the host can detect stale context.

The code does **not** call an LLM. A repository-capable agent follows the protocol;
the provided runtime checks its data artifacts. There is no automatic model
profiler, representation optimizer, hole solver, native compiler, or GPU executor.
The GPU document is a design case, not a supported execution pack.

## Run the small example

From this directory, inspect the reference implementation, then extract only its
reviewed Python block. This command creates a local `reference.py`, which is not
part of the Markdown-only distribution.

```sh
python - <<'PYCODE'
from pathlib import Path
text = Path('runtime/REFERENCE.md').read_text(encoding='utf-8')
start = text.index('```python\n') + len('```python\n')
end = text.index('\n```', start)
Path('reference.py').write_text(text[start:end] + '\n', encoding='utf-8')
PYCODE
python reference.py --selftest
python reference.py --capsule examples/intseq/CAPSULE.md --program examples/intseq/PROGRAM.md --input '[-2,-1,0,2]'
```

The second command returns `16`, along with the expanded primitive program.
`EVALUATED` explicitly does not mean that an arbitrary user task was solved.
See [runtime capabilities](runtime/HOST.md) and [evidence](core/EVIDENCE.md).

## The central boundary

The LLM may change the **problem-facing representation**. It may not silently
change the **problem, semantic implementation, checker, or execution authority**.
A new primitive requires a separately reviewed implementation. A new spelling or
compositional macro does not get a new meaning by assertion.

The development protocol and its budgets are policies for an agent or host to
implement, not controls magically enforced by Markdown. The reference enforces
only the documented intseq subset.

## Publication and maintenance

This is a local repository distribution, not a published remote. The files can
be added to an existing Git repository or initialized and uploaded to GitHub.
[MANIFEST.md](MANIFEST.md) records file hashes and byte sizes. Review source and
choose a project license before public release; this starter intentionally does
not assign a copyright holder or licensing preference on your behalf.
