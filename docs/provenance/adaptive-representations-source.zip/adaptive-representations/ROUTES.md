# Context routes

Do not bulk-read the repository. Load explicit dependencies once per version.
The host or agent performs retrieval; Markdown links are not automatic includes.

| Current activity | Read next | Do not load by default |
|---|---|---|
| Decide whether adaptation helps | core/ECONOMICS.md, templates/TASK.md | research history |
| Construct a capsule | roles/SYNTHESIZER.md, core/CAPSULE.md, selected pack | other domain packs |
| Generate a program | roles/PROGRAMMER.md, frozen task + capsule, selected tutorial | rejected capsules, reference oracle, research files |
| Review a proposed result | roles/REVIEWER.md, core/EVIDENCE.md, run record | unrelated examples |
| Diagnose a failure | core/PROTOCOL.md, exact diagnostic, relevant operation | whole attempt history |
| Add a primitive or backend | core/EVOLUTION.md, core/SEMANTICS.md, runtime/HOST.md | ordinary coding route |
| Run intseq locally | runtime/REFERENCE.md, examples/intseq/CAPSULE.md, examples/intseq/PROGRAM.md | GPU case |
| Design a GPU norm pack | packs/gpu/RMSNORM.md | any claim that intseq supports GPU execution |
| Conduct research | research/THESIS.md, research/EVALUATION.md, research/RELATED-WORK.md | no default runtime action |

## Context assembly policy

Always provide the frozen task, capsule identity, permitted operation semantics,
and required output shape to the programmer. Never save tokens by omitting a
precondition that changes meaning. Examples supplement, not replace, semantics.

The complete capsule is deliberately small in v0.1. For future larger packs,
include the transitive closure of definitions actually used. Keep stable IDs so
an operation can be fetched without searching prose. Cache by exact content hash.

Measure prompt bytes and actual provider token usage separately. This repository
does not claim a tokenizer-independent token count or an experimentally optimal
context size. Model-specific tutorials are a future experiment, not an assumption.

For a worked one-call context view, see
[examples/intseq/PACKET.md](examples/intseq/PACKET.md). This derived packet records
its source file identities; it is not a second independent semantic specification.
An external host must verify freshness and assemble analogous packets for new
tasks. The reference interpreter does not implement that context-assembly step.
