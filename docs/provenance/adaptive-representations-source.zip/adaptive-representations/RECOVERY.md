# Source archive recovery

The source archive originally intended for publication was truncated in the
Git blob. This recovery container preserves every original source file whose
exact bytes can be independently recovered from surviving ZIP records or Git
history. Missing originals are listed by their previously recorded identity;
no bytes are fabricated to satisfy those hashes.

- Historical intended archive SHA-256: `2ef132444533406479eb1ad54afe5bd5be364803aed166b4f3b15f41d5d0f0ca`
- Published truncated blob SHA-256: `395880b60332513c0b50f6f00c9ed172b5f5669d5d35910fdddb52630bdddc77`
- Exact original source files recovered: **27 / 36**

## Unavailable original source bytes

| Path | Bytes | Recorded SHA-256 |
|---|---:|---|
| `START.md` | 1555 | `3efe53059decce4dca96190610275a2d4133245d64dbcda584d8bb310796bc90` |
| `examples/intseq/EVIDENCE.md` | 4875 | `358dd01d26abfe34417b0476252bf3b36765d23be343588a5076d759e3f0087d` |
| `research/EVALUATION.md` | 4083 | `72f3ea0fcbc4650583400147098c0dc60ca3842ddd3ce3b3fae8e98944cd22cf` |
| `research/RELATED-WORK.md` | 4183 | `7885e232f76acda8cefce166a2e1633bd50449d74158bf129e5876d668897715` |
| `research/ROADMAP.md` | 2550 | `5f4187ca83d53177c4cc7d0c718448a1fc1ac235074c79b0d88f6fb3e332d72b` |
| `research/THESIS.md` | 10506 | `5f6c38b23ecee81939db12b06f4ebc4ef54be0e62fa71f318546e10bc2b84a6e` |
| `runtime/HOST.md` | 2332 | `5097e8810e26837e05001a5d82577cf9b6fd4b33bbc9d1039a6378e1fa5e497b` |
| `runtime/REFERENCE.md` | 16741 | `6c3254e60778efb66092f2e6ffc1e00362b71a16208c60a50ec9fa117f95d1b3` |
| `templates/RUN.md` | 1097 | `cbdd3620797b43d1a96d9b3368a7cd3caaf1e39db856c9655248ef7d01b8d066` |
