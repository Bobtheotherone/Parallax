# Repository manifest

A deterministic path index for local retrieval. All deliverables are Markdown.
Hashes below are whole-file SHA-256 over stored UTF-8 bytes, not capsule identities.
The manifest excludes its own hash to avoid a circular dependency. It is not a
signature, trust anchor, automatic include mechanism, or dependency lockfile for
external runtimes. Review and pin the repository through your host workflow.

| Path | Bytes | SHA-256 |
|---|---:|---|
| [AGENTS.md](AGENTS.md) | 1543 | `f209372251ddfcb0f3bed551f0e400967f9abe4436de8ff5394a9e5b0358dc64` |
| [CHANGELOG.md](CHANGELOG.md) | 463 | `1ec4809afd9c6a1d5ca92dd4df173c36f9e82d71e49ee04344f1262dde26efbc` |
| [README.md](README.md) | 4131 | `8bf93e493899309bfd8ce90284e49b3e186bf59f5872f7e8b262106080876874` |
| [ROUTES.md](ROUTES.md) | 2348 | `fada845a03d4090f396a5a812bb2e5e0716bb61802a0492dd7ac8cd7d1675a42` |
| [START.md](START.md) | 1555 | `3efe53059decce4dca96190610275a2d4133245d64dbcda584d8bb310796bc90` |
| [core/CAPSULE.md](core/CAPSULE.md) | 2388 | `d99fe105a0bae133c588a7e89bc445a072525ec85861a67f224f264542ae752a` |
| [core/CONTRACT.md](core/CONTRACT.md) | 2023 | `12f869dd8655239d4ff041103724a3ea96f27e5a41ef54ee3098f236839bb028` |
| [core/ECONOMICS.md](core/ECONOMICS.md) | 2220 | `1d2abc029d605d5ed4ae6ba6b69de0fc6332de28812a5f27f610965ffb1c38a4` |
| [core/EVIDENCE.md](core/EVIDENCE.md) | 2366 | `4f9df6992dbf2cc17beb40aa5ac4254a1e744a208a2455bce7614479a5603119` |
| [core/EVOLUTION.md](core/EVOLUTION.md) | 2170 | `4f3550974d45c2b22c00ee68697eb2756cfd81bf41140729e255bac2dc0fb7a8` |
| [core/PROTOCOL.md](core/PROTOCOL.md) | 2865 | `2536a30dce0b598f5f041fdc0e5433965bfce2bb3c3c7d057d769ad9ba016b0d` |
| [core/SEMANTICS.md](core/SEMANTICS.md) | 2863 | `bf79cc95a114cd4682e07d4aed69fe11a8c709f63423d39bf1d38e84b6f8fbaa` |
| [examples/intseq/CAPSULE.md](examples/intseq/CAPSULE.md) | 788 | `33bd94fe2226635f81af35fe5b897f618d036d0d2341aac0e8694a6aaca812d8` |
| [examples/intseq/EVIDENCE.md](examples/intseq/EVIDENCE.md) | 4875 | `358dd01d26abfe34417b0476252bf3b36765d23be343588a5076d759e3f0087d` |
| [examples/intseq/FAILURE.md](examples/intseq/FAILURE.md) | 964 | `94fbcb06c8fc338bba2c37a3445c26d0395cf888888aa11bde314535697f36dd` |
| [examples/intseq/PACKET.md](examples/intseq/PACKET.md) | 3796 | `cc68fa2bb52a4c175390f600c776bcffc2f5438afd538df3936909aa0465dc7c` |
| [examples/intseq/PROGRAM.md](examples/intseq/PROGRAM.md) | 435 | `4563c0af751770e7e0c31d16318cd143ed50ea682f1eab7fa93f397967b405e5` |
| [examples/intseq/TASK.md](examples/intseq/TASK.md) | 1930 | `f08bce72ad70d544409917c41af5b07dcb9a15c84731b733f32b40464a9b4f50` |
| [packs/gpu/RMSNORM.md](packs/gpu/RMSNORM.md) | 3880 | `a8f27c270fa552108cca6d0de62f6cf596d5d3b858febc2d89f040fcea5ca891` |
| [packs/intseq/CAPSULE.md](packs/intseq/CAPSULE.md) | 2185 | `f38fcb922a05528d1dc8db48127a6bb5eef4a5555420bf2f35f5886ef5a30029` |
| [packs/intseq/PACK.md](packs/intseq/PACK.md) | 3160 | `1d3de58d8bbdb9334f2fee2d40135aada79e26b35decc9cbe146e0c099ff717b` |
| [packs/intseq/TUTORIAL.md](packs/intseq/TUTORIAL.md) | 1544 | `d6e3093669b3d9495101eea6115ccdd8cfd237f9686e6bd35e02f41531553753` |
| [research/EVALUATION.md](research/EVALUATION.md) | 4083 | `72f3ea0fcbc4650583400147098c0dc60ca3842ddd3ce3b3fae8e98944cd22cf` |
| [research/RELATED-WORK.md](research/RELATED-WORK.md) | 4183 | `7885e232f76acda8cefce166a2e1633bd50449d74158bf129e5876d668897715` |
| [research/ROADMAP.md](research/ROADMAP.md) | 2550 | `5f4187ca83d53177c4cc7d0c718448a1fc1ac235074c79b0d88f6fb3e332d72b` |
| [research/THESIS.md](research/THESIS.md) | 10506 | `5f6c38b23ecee81939db12b06f4ebc4ef54be0e62fa71f318546e10bc2b84a6e` |
| [roles/PROGRAMMER.md](roles/PROGRAMMER.md) | 1287 | `6d13cda30c80161317b29ed7f450c8367b49072d8cd1de2839e2ecbd3f9736a9` |
| [roles/REVIEWER.md](roles/REVIEWER.md) | 1192 | `2390bb5255a0117280b37cd1b7749a75116311c751b1e731728b408154fdfcd4` |
| [roles/SYNTHESIZER.md](roles/SYNTHESIZER.md) | 1273 | `1f15e477c0fcfe5e96c506bf8fe271e933f136ff369df294f44db089af335b80` |
| [runtime/HOST.md](runtime/HOST.md) | 2332 | `5097e8810e26837e05001a5d82577cf9b6fd4b33bbc9d1039a6378e1fa5e497b` |
| [runtime/REFERENCE.md](runtime/REFERENCE.md) | 16741 | `6c3254e60778efb66092f2e6ffc1e00362b71a16208c60a50ec9fa117f95d1b3` |
| [templates/CAPSULE.md](templates/CAPSULE.md) | 537 | `1c72bfd4e81b35b7598bcff471a181fba91b6c86212aaaf12c541559eb350310` |
| [templates/EXTENSION.md](templates/EXTENSION.md) | 887 | `fefd94dad19db75c12a4142c3b14507760a42cdee06c6785d5a269ffc5f1c629` |
| [templates/RUN.md](templates/RUN.md) | 1097 | `cbdd3620797b43d1a96d9b3368a7cd3caaf1e39db856c9655248ef7d01b8d066` |
| [templates/TASK.md](templates/TASK.md) | 844 | `a42070e9816ead3b7868f0037cb9e85c20269409d11d65ec13ac6391666a2d09` |
