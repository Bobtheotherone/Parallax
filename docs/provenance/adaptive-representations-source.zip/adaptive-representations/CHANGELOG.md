# Changelog

## 0.1 — 2026-09-05

Initial Markdown-only research starter. Added contract/capsule/evidence separation,
bounded agent protocol, selective context routes, exact-integer reference and
worked example, GPU reduction-scope design critique, and matched-budget evaluation
plan with selected primary-source positioning.

No LLM synthesis benchmark, GPU execution, native compiler, formal proof, or
GitHub publication was performed by the bundled runtime.
